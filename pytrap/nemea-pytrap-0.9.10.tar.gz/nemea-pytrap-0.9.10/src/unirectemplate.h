#ifndef UNIRECTEMPLATE_H
#define UNIRECTEMPLATE_H
#ifdef __cplusplus
extern "C" {
#endif

PyAPI_FUNC(PyObject *) UnirecTemplate_getAttr(pytrap_unirectemplate *self, PyObject *attr);

#ifdef __cplusplus
}
#endif
#endif

